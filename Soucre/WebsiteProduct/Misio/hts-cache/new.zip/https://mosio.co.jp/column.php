<!DOCTYPE html>
<html lang="ja">
<head>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-108057721-1', 'auto');
  ga('send', 'pageview');

</script><meta charset="utf-8">
<title>人々のはなし｜COLUMN｜塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO</title>



<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="format-detection" content="telephone=no">
<meta name="description" content="塩竈の藻塩は、宮城県塩竈市に塩土老翁神が伝えたとされる伝統的な製法に習い製塩されています。SHIOGAMA NO MOSHIO is made in traditional way in Shiogama City, Miyagi prefecture.">
<meta name="keywords" content="塩竈の藻塩,塩竈製塩,合同会社顔晴れ塩竈,SHIOGAMA NO MOSHIO,SHIOGAMA SEIEN,GANBARE SHIOGAMA LLC">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<meta property="og:site_name" content="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO">
<meta property="og:description" content="塩竈の藻塩は、宮城県塩竈市に塩土老翁神が伝えたとされる伝統的な製法に習い製塩されています。SHIOGAMA NO MOSHIO is made in traditional way in Shiogama City, Miyagi prefecture.">
<meta property="og:image" content="https://mosio.co.jp/img/fb_thumbnail.png">
<link rel="apple-touch-icon" href="https://mosio.co.jp/img/apple-touch-icon.png">
<link rel="icon" type="image/x-icon" href="https://mosio.co.jp/img/favicon.ico">
<link rel="canonical" href="https://mosio.co.jp">



<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Cinzel|Lato">
<link rel="stylesheet" type="text/css" href="https://mosio.co.jp/css/style.css?201909">
<link rel="stylesheet" type="text/css" href="https://mosio.co.jp/css/common.css?2021">



</head>
<body>



<!--/WRAP/-->
<div class="wrap">



	<!--/OPENING/-->
	<div class="opening">		
		<div class="opening_bar"><span></span></div>	
		<div class="opening_text"><p class="kerning en0">
			<span class="opa">S</span><span class="opa">H</span><span class="opa">I</span><span class="opa">O</span><span class="opa">G</span><span class="opa">A</span><span class="opa">M</span><span class="opa">A</span><span class="opa">&nbsp;</span><span class="opa">N</span><span class="opa">O</span><span class="opa">&nbsp;</span><span class="opa">M</span><span class="opa">O</span><span class="opa">S</span><span class="opa">H</span><span class="opa">I</span><span class="opa">O</span>
		</p></div>	
	</div>	
	


	<!--/LOADING/-->
	<div class="loading none">		
		<div class="loading_inner">
			<div class="loading_blue"></div>	
			<div class="loading_white"></div>	
		</div>	
	</div>	



	<!--/HEADER/-->
	<div class="header">	
		<a href="javascript:void(0);" class="header_button">
			<div class="header_button_bg opa"></div>	
			<div class="header_button_inner">
				<div><span></span><span></span><span></span></div>
				<div><span></span><span></span><span></span></div>
				<div><span></span><span></span><span></span></div>	
			</div>			
		</a>	
	</div>	



	<!--/MENU/-->
	<div class="menu none">	
		<div class="menu_inner opa">
			<div class="menu_bg"></div>		
			<div class="menu_block">	
				<a href="https://mosio.co.jp/" class="menu_list opa link">	
					<div><p class="kerning">ホーム</p></div>
					<div>
						<p class="kerning en0">HOME</p>
						<p class="kerning en0">HOME</p>
						<p class="kerning en0"><span>HOME</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/product.php" class="menu_list opa link">	
					<div><p class="kerning">塩竈の藻塩</p></div>
					<div>
						<p class="kerning en0">PRODUCT</p>
						<p class="kerning en0">PRODUCT</p>
						<p class="kerning en0"><span>PRODUCT</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/about.php" class="menu_list opa link">	
					<div><p class="kerning">藻塩について</p></div>
					<div>
						<p class="kerning en0">ABOUT</p>
						<p class="kerning en0">ABOUT</p>
						<p class="kerning en0"><span>ABOUT</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/recipe.php" class="menu_list opa link">	
					<div><p class="kerning">藻塩レシピ</p></div>
					<div>
						<p class="kerning en0">RECIPE</p>
						<p class="kerning en0">RECIPE</p>
						<p class="kerning en0"><span>RECIPE</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/column.php" class="menu_list opa link">	
					<div><p class="kerning">人々のはなし</p></div>
					<div>
						<p class="kerning en0">COLUMN</p>
						<p class="kerning en0">COLUMN</p>
						<p class="kerning en0"><span>COLUMN</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/shop.php" class="menu_list opa link">	
					<div><p class="kerning">販売店一覧</p></div>
					<div>
						<p class="kerning en0">SHOP</p>
						<p class="kerning en0">SHOP</p>
						<p class="kerning en0"><span>SHOP</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/faq.php" class="menu_list opa link">	
					<div><p class="kerning">よくあるご質問</p></div>
					<div>
						<p class="kerning en0">FAQ　</p>
						<p class="kerning en0">FAQ　</p>
						<p class="kerning en0"><span>FAQ　</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/company.php" class="menu_list opa link">	
					<div><p class="kerning">企業情報</p></div>
					<div>
						<p class="kerning en0">COMPANY</p>
						<p class="kerning en0">COMPANY</p>
						<p class="kerning en0"><span>COMPANY</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/contact/" class="menu_list opa link">	
					<div><p class="kerning">お問い合わせ</p></div>
					<div>
						<p class="kerning en0">CONTACT</p>
						<p class="kerning en0">CONTACT</p>
						<p class="kerning en0"><span>CONTACT</span></p>
					</div><div class="clear"></div>												
				</a>
			</div>
			<div class="menu_sns opa">
				<a href="https://www.facebook.com/%E5%90%88%E5%90%8C%E4%BC%9A%E7%A4%BE%E9%A1%94%E6%99%B4%E3%82%8C%E5%A1%A9%E7%AB%88-1938148653124259/" target="_blank"><img src="https://mosio.co.jp/img/sns2_w.svg" alt="FACEBOOK"></a>	
				<!--<a href="" target="_blank"><img src="https://mosio.co.jp/img/sns1_w.svg" alt="INSTAGRAM"></a>--><div class="clear"></div>				
			</div>
		</div>
	</div>	


	<!--/CONTENTS/-->
	<div id="top" class="contents">
		<!--/COLUMN/-->	
		<div id="column" class="contents_inner">



			<!--/MAIN/-->
			<div class="contents_main fix_h">
				<div class="contents_main_inner">
					<div class="contents_main_left title_w">
						<a href="/" class="contents_main_logo link"><img src="/img/logo0.svg" alt="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO"></a>
						<div class="contents_main_title"><img src="/img/title4.svg" alt="人々のおはなし"></div>					
					</div>
					<div class="contents_main_right">
						<div class="contents_main_img"><div></div></div>
					</div>
				</div>
			</div>



			<!--/DETAIL/-->
			<div class="contents_detail">
				<div class="contents_detail_inner">



					<div id="subtitle" class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner contents_w">
							<div class="contents_block_subtitle"><p class="kerning en0">COLUMN</p></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_text"><p class="kerning ja0">塩の作り手と生かし手。<br>『塩竈の藻塩』をとりまく<br class="sp_disp">技術者たちの言葉をご紹介します。</p></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="column_title">
								<p class="kerning ja0">藻塩と製塩職人</p>
								<p class="kerning en0">story.01</p>
								<p class="kerning">合同会社 顔晴れ塩竈／及川文男さん</p>
							</div>
							<div class="column_contents">
								<div class="column_copy"><p class="kerning ja0"><span>「</span>手間暇をかけた分だけ、<br class="tb_disp sp_disp">塩の味がまろやかになる<span>」</span></p></div>							
								<div class="column_left">
									<div class="column_illust"><img src="/img/illust2.svg"></div>
								</div>
								<div class="column_right">					
									<div class="column_text">
										<p class="kerning">『塩竈の藻塩』を製造する「合同会社 顔晴れ（がんばれ）塩竈」の製塩職人の及川文男さんは、昭和10年創業の水産加工会社「及川商店」の経営者でもあります。<br><br>及川さんの「塩作りの聖地で塩を生産していないのはおかしい」との思いに、塩作りを地域活性化につなげようという地元の若者の動きが重なり、2009年の4月、及川商店の工房に設えた竈で『塩竈の藻塩』の生産は始まりました。<br><br>「顔晴れ塩竈」の塩づくりは、この地に伝わる塩土老翁神の製塩法を踏襲し、「手間暇かけて、手塩にかけて」行われます。<br><br>「海水を炊く間、雑味のもとになる不純物を取り除き続けます。手間をかけた分だけ、まろやかな塩に仕上がりますから。地元の料理人や菓子職人が『塩竈の藻塩』を使ってくれるのも、塩竈産という価値だけでなく、この塩の味を評価してくれているからなんです」と及川さん。<br><br>及川さんの塩作りは、地域の人々の新たなつながりも生み出しています。</p>
										<div></div>
										<p class="kerning">合同会社 顔晴れ塩竈<br>宮城県塩竈市尾島町27-30 キクニ（株）2F<br>TEL.022-365-5572</p>
									</div>
								</div><div class="clear"></div>
							</div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="column_title">
								<p class="kerning ja0">藻塩と寿司職人</p>
								<p class="kerning en0">story.02</p>
								<p class="kerning">亀喜寿司／保志昌宏さん</p>
							</div>
							<div class="column_contents">
								<div class="column_copy"><p class="kerning ja0"><span>「</span>地元産の魚介の味を、<br class="tb_disp sp_disp">地元産の藻塩が引き出してくれる<span>」</span></p></div>						
								<div class="column_left">
									<div class="column_illust"><img src="/img/illust3.svg"></div>
								</div>
								<div class="column_right">					
									<div class="column_text">
										<p class="kerning">保志昌宏さんは、大正時代創業の老舗「亀喜寿司」の5代目。「亀喜寿司」は地元産の魚介を生かした寿司を味わえる名店です。<br><br>保志さんは食材の質や調理技術はもちろん、食材の「物語」を大事にしています。寿司に使われる魚介の産地や漁法、調理法など、その食材の背景をお客さんに伝えることで、料理をより深く味わってもらえるのだそうです。そして、料理に塩竈産の塩を使うことで、その「物語」に深みが増すのです。<br><br>もちろん保志さんが『塩竈の藻塩』を使う理由は「物語」だけではありません。<br>「三陸産の魚介は質がいい。だからこそ、雑味のない『塩竈の藻塩』が、素材の味を引き立ててくれるんです。まして、地元の魚介を育んだ、その海水から作られた地元の塩。相性がいいのは当然です」と話す保志さん。<br><br>「亀喜寿司」では、ウニやアナゴなど保志さんが選んだ素材を、細かく砕いた『塩竈の藻塩』の結晶とともに味わうことができます。</p>
										<div></div>
										<p class="kerning">亀喜寿司<br>宮城県塩竈市新富町6−12<br>TEL.022-362-2055</p>
									</div>
								</div><div class="clear"></div>
							</div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="column_title">
								<p class="kerning ja0">藻塩と菓子職人</p>
								<p class="kerning en0">story.03</p>
								<p class="kerning">チョコレート工房 クレオバンテール／渡辺誠二さん</p>
							</div>
							<div class="column_contents">
								<div class="column_copy"><p class="kerning ja0"><span>「</span>この塩との出会いが、<br class="tb_disp sp_disp">塩竈に店を開くきっかけに<span>」</span></p></div>						
								<div class="column_left">
									<div class="column_illust"><img src="/img/illust4.svg"></div>
								</div>
								<div class="column_right">					
									<div class="column_text">
										<p class="kerning">「この塩を初めて口に含んだとき、チョコレートに合うと直感しました」と話すのは、「チョコレート工房 クレオバンテール」代表の渡辺誠二さんです。<br><br>渡辺さんは洋菓子作りに使う塩を求めて日本各地を歩き回った末に、『塩竈の藻塩』に出会いました。<br>そしてすぐに、藻塩を使ったビスケットとチョコレートクリームを合わせて藻塩の結晶をトッピングした「藻塩ショコラ」を試作。手応えをつかみ、塩竈にチョコレートのお店を開くきっかけになりました。<br><br>「クセがなく、優しい塩気の後に甘みが返ってくる。純粋に美味しい塩だと思います」と、『塩竈の藻塩』の魅力を語る渡辺さん。「この塩でお菓子を作ると、お菓子の味が引き出され、深みが増すんです」と言います。<br><br>そんな渡辺さんが営む「チョコレート工房 クレオバンテール」では、「藻塩ショコラ」だけでなく、柔らかな塩味が魅力のクッキーやマドレーヌも人気です。</p>
										<div></div>
										<p class="kerning">チョコレート工房 クレオバンテール<br>宮城県塩竈市本町6−4<br>TEL.022-781-8301</p>
									</div>
								</div><div class="clear"></div>
							</div>
						</div>
					</div>
					


				</div>
			</div>



		</div>
	</div>



	<!--/FOOTER/-->
	<div class="footer scroll_element scroll_off">	
		<div class="footer_inner">	
			<div class="footer_button">	
				<a href="https://mosio.co.jp/shop.php" class="link"><span></span><p class="kerning en0">SHOP</p><p class="kerning ja0">販売店一覧</p></a>
				<a href="https://mosio.co.jp/contact/" class="link"><span></span><p class="kerning en0">CONTACT</p><p class="kerning ja0">お問い合わせ</p></a><div class="clear"></div>
			</div>	
			<a href="https://mosio.co.jp/" class="footer_logo link"><img src="https://mosio.co.jp/img/logo0.svg" alt="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO"></a>		
			<div class="footer_text">	
				<p class="kerning">合同会社 顔晴れ塩竈</p>
				<p class="kerning">事務所<br>〒985‐0021 宮城県塩竈市尾島町27‐30キクニ（株）2F<br>TEL.022‐365‐5572　FAX.022‐361‐3370</p>
				<p class="kerning">工場<br>〒985‐0016 宮城県塩竈市港町二丁目15‐9<br>TEL.022‐367‐6539　FAX.022‐367‐6539</p><div class="clear"></div>
			</div>		
			<div class="footer_sns">	
				<a href="https://www.facebook.com/%E5%90%88%E5%90%8C%E4%BC%9A%E7%A4%BE%E9%A1%94%E6%99%B4%E3%82%8C%E5%A1%A9%E7%AB%88-1938148653124259/" target="_blank"><img src="https://mosio.co.jp/img/sns0_b.svg" alt="FACEBOOK"></a>	
				<!--<a href="" target="_blank"><img src="https://mosio.co.jp/img/sns1_b.svg" alt="INSTAGRAM"></a>--><div class="clear"></div>
			</div>	
			<a href="https://mosio.co.jp/notices.php" class="footer_notices link"><p class="kerning">特定商取引法に基づく表記</p></a>					
			<div class="footer_copyright"><p class="kerning">© 2017 GANBARE SHIOGAMA LLC</p></div>	
		</div>	
	</div>	
	
	

</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="https://mosio.co.jp/js/jquery-2.1.3.min.js"><\/script>')</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?language=en&key=AIzaSyAi_P2BfqNYcPbD-5mj6uYFJVidhSJjMXk"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.bxslider.min.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.pjax.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/common.js?201903"></script>



</body>
</html>