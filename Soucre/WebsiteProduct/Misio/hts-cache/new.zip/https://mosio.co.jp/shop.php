<!DOCTYPE html>
<html lang="ja">
<head>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-108057721-1', 'auto');
  ga('send', 'pageview');

</script><meta charset="utf-8">
<title>販売店一覧｜SHOP｜塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO</title>



<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="format-detection" content="telephone=no">
<meta name="description" content="塩竈の藻塩は、宮城県塩竈市に塩土老翁神が伝えたとされる伝統的な製法に習い製塩されています。SHIOGAMA NO MOSHIO is made in traditional way in Shiogama City, Miyagi prefecture.">
<meta name="keywords" content="塩竈の藻塩,塩竈製塩,合同会社顔晴れ塩竈,SHIOGAMA NO MOSHIO,SHIOGAMA SEIEN,GANBARE SHIOGAMA LLC">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<meta property="og:site_name" content="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO">
<meta property="og:description" content="塩竈の藻塩は、宮城県塩竈市に塩土老翁神が伝えたとされる伝統的な製法に習い製塩されています。SHIOGAMA NO MOSHIO is made in traditional way in Shiogama City, Miyagi prefecture.">
<meta property="og:image" content="https://mosio.co.jp/img/fb_thumbnail.png">
<link rel="apple-touch-icon" href="https://mosio.co.jp/img/apple-touch-icon.png">
<link rel="icon" type="image/x-icon" href="https://mosio.co.jp/img/favicon.ico">
<link rel="canonical" href="https://mosio.co.jp">



<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Cinzel|Lato">
<link rel="stylesheet" type="text/css" href="https://mosio.co.jp/css/style.css?201909">
<link rel="stylesheet" type="text/css" href="https://mosio.co.jp/css/common.css?2021">



</head>
<body>



<!--/WRAP/-->
<div class="wrap">



	<!--/OPENING/-->
	<div class="opening">		
		<div class="opening_bar"><span></span></div>	
		<div class="opening_text"><p class="kerning en0">
			<span class="opa">S</span><span class="opa">H</span><span class="opa">I</span><span class="opa">O</span><span class="opa">G</span><span class="opa">A</span><span class="opa">M</span><span class="opa">A</span><span class="opa">&nbsp;</span><span class="opa">N</span><span class="opa">O</span><span class="opa">&nbsp;</span><span class="opa">M</span><span class="opa">O</span><span class="opa">S</span><span class="opa">H</span><span class="opa">I</span><span class="opa">O</span>
		</p></div>	
	</div>	
	


	<!--/LOADING/-->
	<div class="loading none">		
		<div class="loading_inner">
			<div class="loading_blue"></div>	
			<div class="loading_white"></div>	
		</div>	
	</div>	



	<!--/HEADER/-->
	<div class="header">	
		<a href="javascript:void(0);" class="header_button">
			<div class="header_button_bg opa"></div>	
			<div class="header_button_inner">
				<div><span></span><span></span><span></span></div>
				<div><span></span><span></span><span></span></div>
				<div><span></span><span></span><span></span></div>	
			</div>			
		</a>	
	</div>	



	<!--/MENU/-->
	<div class="menu none">	
		<div class="menu_inner opa">
			<div class="menu_bg"></div>		
			<div class="menu_block">	
				<a href="https://mosio.co.jp/" class="menu_list opa link">	
					<div><p class="kerning">ホーム</p></div>
					<div>
						<p class="kerning en0">HOME</p>
						<p class="kerning en0">HOME</p>
						<p class="kerning en0"><span>HOME</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/product.php" class="menu_list opa link">	
					<div><p class="kerning">塩竈の藻塩</p></div>
					<div>
						<p class="kerning en0">PRODUCT</p>
						<p class="kerning en0">PRODUCT</p>
						<p class="kerning en0"><span>PRODUCT</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/about.php" class="menu_list opa link">	
					<div><p class="kerning">藻塩について</p></div>
					<div>
						<p class="kerning en0">ABOUT</p>
						<p class="kerning en0">ABOUT</p>
						<p class="kerning en0"><span>ABOUT</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/recipe.php" class="menu_list opa link">	
					<div><p class="kerning">藻塩レシピ</p></div>
					<div>
						<p class="kerning en0">RECIPE</p>
						<p class="kerning en0">RECIPE</p>
						<p class="kerning en0"><span>RECIPE</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/column.php" class="menu_list opa link">	
					<div><p class="kerning">人々のはなし</p></div>
					<div>
						<p class="kerning en0">COLUMN</p>
						<p class="kerning en0">COLUMN</p>
						<p class="kerning en0"><span>COLUMN</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/shop.php" class="menu_list opa link">	
					<div><p class="kerning">販売店一覧</p></div>
					<div>
						<p class="kerning en0">SHOP</p>
						<p class="kerning en0">SHOP</p>
						<p class="kerning en0"><span>SHOP</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/faq.php" class="menu_list opa link">	
					<div><p class="kerning">よくあるご質問</p></div>
					<div>
						<p class="kerning en0">FAQ　</p>
						<p class="kerning en0">FAQ　</p>
						<p class="kerning en0"><span>FAQ　</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/company.php" class="menu_list opa link">	
					<div><p class="kerning">企業情報</p></div>
					<div>
						<p class="kerning en0">COMPANY</p>
						<p class="kerning en0">COMPANY</p>
						<p class="kerning en0"><span>COMPANY</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/contact/" class="menu_list opa link">	
					<div><p class="kerning">お問い合わせ</p></div>
					<div>
						<p class="kerning en0">CONTACT</p>
						<p class="kerning en0">CONTACT</p>
						<p class="kerning en0"><span>CONTACT</span></p>
					</div><div class="clear"></div>												
				</a>
			</div>
			<div class="menu_sns opa">
				<a href="https://www.facebook.com/%E5%90%88%E5%90%8C%E4%BC%9A%E7%A4%BE%E9%A1%94%E6%99%B4%E3%82%8C%E5%A1%A9%E7%AB%88-1938148653124259/" target="_blank"><img src="https://mosio.co.jp/img/sns2_w.svg" alt="FACEBOOK"></a>	
				<!--<a href="" target="_blank"><img src="https://mosio.co.jp/img/sns1_w.svg" alt="INSTAGRAM"></a>--><div class="clear"></div>				
			</div>
		</div>
	</div>	


	<!--/CONTENTS/-->
	<div id="top" class="contents">
		<!--/SHOP/-->	
		<div id="shop" class="contents_inner">



			<!--/MAIN/-->
			<div class="contents_main fix_h">
				<div class="contents_main_inner">
					<div class="contents_main_left title_w">
						<a href="/" class="contents_main_logo link"><img src="/img/logo0.svg" alt="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO"></a>
						<div class="contents_main_title"><img src="/img/title5.svg" alt="販売店一覧"></div>					
					</div>
					<div class="contents_main_right">
						<div class="contents_main_img"><div></div></div>
					</div>
				</div>
			</div>



			<!--/DETAIL/-->
			<div class="contents_detail">
				<div class="contents_detail_inner">



					<div id="subtitle" class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner contents_w">
							<div class="contents_block_subtitle"><p class="kerning en0">SHOP</p></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="shop_area"><p class="kerning">東北</p></div>
							
							<div class="shop_list">
								<p class="kerning ja0">しおがま・まちの駅</p>
								<p class="kerning">〒985-0002	宮城県塩竈市海岸通14-6<br>TEL.022-367-9651　FAX.022-367-9651<br><a href="http://shiogamachinoeki.main.jp" target="_blank">http://shiogamachinoeki.main.jp</a></p><div class="clear"></div>
							</div>
							
							<div class="shop_list">
								<p class="kerning ja0">しおがまパノラマ</p>
								<p class="kerning">〒985-0052	宮城県塩竈市本町2-10<br>TEL.022-794-9113<br>http://islandscourt.com</p><div class="clear"></div>
							</div>
							
							<div class="shop_list">
								<p class="kerning ja0">熊久商店</p>
								<p class="kerning">〒985-0052	宮城県塩竈市本町11-5<br>TEL.022-362-0441</p><div class="clear"></div>
							</div>
							
							<div class="shop_list">
								<p class="kerning ja0">太田與八郎商店</p>
								<p class="kerning">〒985-0051	宮城県塩竈市宮町2-24<br>TEL.022-362-0035</p><div class="clear"></div>
							</div>							
							
							<div class="shop_list">
								<p class="kerning ja0">夕里屋</p>
								<p class="kerning">〒985-0016	宮城県塩竈市港町1-4-1<br>TEL.090-7067-6140</p><div class="clear"></div>
							</div>							
							
							<div class="shop_list">
								<p class="kerning ja0">塩釜水産物仲卸市場</p>
								<p class="kerning">〒985-0001	宮城県塩竈市新浜町1-20-74<br>TEL.022-362-5518<br><a href="http://www.nakaoroshi.or.jp" target="_blank">http://www.nakaoroshi.or.jp</a></p><div class="clear"></div>
							</div>									
							
							<div class="shop_list">
								<p class="kerning ja0">東北めぐり いろといろ</p>
								<p class="kerning">〒980-0021	宮城県仙台市青葉区中央1-1-1 エスパル仙台東館2F<br>TEL.022-385-6245</p><div class="clear"></div>
							</div>
							
							<div class="shop_list">
								<p class="kerning ja0">うす皮たい焼き　鯛きち</p>
								<p class="kerning">〒980-0021	宮城県仙台市青葉区中央2-1-30 須田ビル1F<br>TEL.022-224-7233<br><a href="http://taiankichijitsu.com" target="_blank">http://taiankichijitsu.com</a></p><div class="clear"></div>
							</div>

							<div class="shop_list">
								<p class="kerning ja0">（株）水沢種苗店 グリーンサムいちば</p>
								<p class="kerning">〒986-0868	宮城県石巻市恵み野6丁目4-4<br>TEL.0225-96-8713<br><a href="http://www.mizusawa-seed.co.jp" target="_blank">http://www.mizusawa-seed.co.jp</a></p><div class="clear"></div>
							</div>	
							
							<div class="shop_list">
								<p class="kerning ja0">（同）粋 sui</p>
								<p class="kerning">〒989-0231 宮城県白石市福岡蔵本字鎌先1番58-4<br>TEL.0224-26-8100</p><div class="clear"></div>
							</div>	
							
							<div class="shop_list">
								<p class="kerning ja0">ほやほや屋</p>
								<p class="kerning">〒985-0003 宮城県塩竈市北浜1丁目1−7<br>TEL.022-355-6106</p><div class="clear"></div>
							</div>								
		
							<div class="clear"></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="shop_area"><p class="kerning">関東</p></div>
							
							<div class="shop_list">
								<p class="kerning ja0">宮城ふるさとプラザ</p>
								<p class="kerning">〒170-0013	東京都豊島区東池袋1-2-2 東池ビル1・2階<br>TEL.03-5956-3511<br><a href="http://cocomiyagi.jp" target="_blank">http://cocomiyagi.jp</a></p><div class="clear"></div>
							</div>
							
							<div class="shop_list">
								<p class="kerning ja0">solco</p>
								<p class="kerning">〒142-0042	東京都品川区豊町1-3-13 モアビル1F<br>TEL.03-6426-8101<br><a href="http://www.solco.co" target="_blank">http://www.solco.co</a></p><div class="clear"></div>
							</div>

							<div class="clear"></div>
						</div>
					</div>



				</div>
			</div>



		</div>
	</div>



	<!--/FOOTER/-->
	<div class="footer scroll_element scroll_off">	
		<div class="footer_inner">	
			<div class="footer_button">	
				<a href="https://mosio.co.jp/shop.php" class="link"><span></span><p class="kerning en0">SHOP</p><p class="kerning ja0">販売店一覧</p></a>
				<a href="https://mosio.co.jp/contact/" class="link"><span></span><p class="kerning en0">CONTACT</p><p class="kerning ja0">お問い合わせ</p></a><div class="clear"></div>
			</div>	
			<a href="https://mosio.co.jp/" class="footer_logo link"><img src="https://mosio.co.jp/img/logo0.svg" alt="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO"></a>		
			<div class="footer_text">	
				<p class="kerning">合同会社 顔晴れ塩竈</p>
				<p class="kerning">事務所<br>〒985‐0021 宮城県塩竈市尾島町27‐30キクニ（株）2F<br>TEL.022‐365‐5572　FAX.022‐361‐3370</p>
				<p class="kerning">工場<br>〒985‐0016 宮城県塩竈市港町二丁目15‐9<br>TEL.022‐367‐6539　FAX.022‐367‐6539</p><div class="clear"></div>
			</div>		
			<div class="footer_sns">	
				<a href="https://www.facebook.com/%E5%90%88%E5%90%8C%E4%BC%9A%E7%A4%BE%E9%A1%94%E6%99%B4%E3%82%8C%E5%A1%A9%E7%AB%88-1938148653124259/" target="_blank"><img src="https://mosio.co.jp/img/sns0_b.svg" alt="FACEBOOK"></a>	
				<!--<a href="" target="_blank"><img src="https://mosio.co.jp/img/sns1_b.svg" alt="INSTAGRAM"></a>--><div class="clear"></div>
			</div>	
			<a href="https://mosio.co.jp/notices.php" class="footer_notices link"><p class="kerning">特定商取引法に基づく表記</p></a>					
			<div class="footer_copyright"><p class="kerning">© 2017 GANBARE SHIOGAMA LLC</p></div>	
		</div>	
	</div>	
	
	

</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="https://mosio.co.jp/js/jquery-2.1.3.min.js"><\/script>')</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?language=en&key=AIzaSyAi_P2BfqNYcPbD-5mj6uYFJVidhSJjMXk"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.bxslider.min.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.pjax.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/common.js?201903"></script>



</body>
</html>