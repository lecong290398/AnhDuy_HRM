<!DOCTYPE html>
<html lang="ja">
<head>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-108057721-1', 'auto');
  ga('send', 'pageview');

</script><meta charset="utf-8">
<title>藻塩について｜ABOUT｜塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO</title>



<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="format-detection" content="telephone=no">
<meta name="description" content="塩竈の藻塩は、宮城県塩竈市に塩土老翁神が伝えたとされる伝統的な製法に習い製塩されています。SHIOGAMA NO MOSHIO is made in traditional way in Shiogama City, Miyagi prefecture.">
<meta name="keywords" content="塩竈の藻塩,塩竈製塩,合同会社顔晴れ塩竈,SHIOGAMA NO MOSHIO,SHIOGAMA SEIEN,GANBARE SHIOGAMA LLC">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<meta property="og:site_name" content="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO">
<meta property="og:description" content="塩竈の藻塩は、宮城県塩竈市に塩土老翁神が伝えたとされる伝統的な製法に習い製塩されています。SHIOGAMA NO MOSHIO is made in traditional way in Shiogama City, Miyagi prefecture.">
<meta property="og:image" content="https://mosio.co.jp/img/fb_thumbnail.png">
<link rel="apple-touch-icon" href="https://mosio.co.jp/img/apple-touch-icon.png">
<link rel="icon" type="image/x-icon" href="https://mosio.co.jp/img/favicon.ico">
<link rel="canonical" href="https://mosio.co.jp">



<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Cinzel|Lato">
<link rel="stylesheet" type="text/css" href="https://mosio.co.jp/css/style.css?201909">
<link rel="stylesheet" type="text/css" href="https://mosio.co.jp/css/common.css?2021">



</head>
<body>



<!--/WRAP/-->
<div class="wrap">



	<!--/OPENING/-->
	<div class="opening">		
		<div class="opening_bar"><span></span></div>	
		<div class="opening_text"><p class="kerning en0">
			<span class="opa">S</span><span class="opa">H</span><span class="opa">I</span><span class="opa">O</span><span class="opa">G</span><span class="opa">A</span><span class="opa">M</span><span class="opa">A</span><span class="opa">&nbsp;</span><span class="opa">N</span><span class="opa">O</span><span class="opa">&nbsp;</span><span class="opa">M</span><span class="opa">O</span><span class="opa">S</span><span class="opa">H</span><span class="opa">I</span><span class="opa">O</span>
		</p></div>	
	</div>	
	


	<!--/LOADING/-->
	<div class="loading none">		
		<div class="loading_inner">
			<div class="loading_blue"></div>	
			<div class="loading_white"></div>	
		</div>	
	</div>	



	<!--/HEADER/-->
	<div class="header">	
		<a href="javascript:void(0);" class="header_button">
			<div class="header_button_bg opa"></div>	
			<div class="header_button_inner">
				<div><span></span><span></span><span></span></div>
				<div><span></span><span></span><span></span></div>
				<div><span></span><span></span><span></span></div>	
			</div>			
		</a>	
	</div>	



	<!--/MENU/-->
	<div class="menu none">	
		<div class="menu_inner opa">
			<div class="menu_bg"></div>		
			<div class="menu_block">	
				<a href="https://mosio.co.jp/" class="menu_list opa link">	
					<div><p class="kerning">ホーム</p></div>
					<div>
						<p class="kerning en0">HOME</p>
						<p class="kerning en0">HOME</p>
						<p class="kerning en0"><span>HOME</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/product.php" class="menu_list opa link">	
					<div><p class="kerning">塩竈の藻塩</p></div>
					<div>
						<p class="kerning en0">PRODUCT</p>
						<p class="kerning en0">PRODUCT</p>
						<p class="kerning en0"><span>PRODUCT</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/about.php" class="menu_list opa link">	
					<div><p class="kerning">藻塩について</p></div>
					<div>
						<p class="kerning en0">ABOUT</p>
						<p class="kerning en0">ABOUT</p>
						<p class="kerning en0"><span>ABOUT</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/recipe.php" class="menu_list opa link">	
					<div><p class="kerning">藻塩レシピ</p></div>
					<div>
						<p class="kerning en0">RECIPE</p>
						<p class="kerning en0">RECIPE</p>
						<p class="kerning en0"><span>RECIPE</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/column.php" class="menu_list opa link">	
					<div><p class="kerning">人々のはなし</p></div>
					<div>
						<p class="kerning en0">COLUMN</p>
						<p class="kerning en0">COLUMN</p>
						<p class="kerning en0"><span>COLUMN</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/shop.php" class="menu_list opa link">	
					<div><p class="kerning">販売店一覧</p></div>
					<div>
						<p class="kerning en0">SHOP</p>
						<p class="kerning en0">SHOP</p>
						<p class="kerning en0"><span>SHOP</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/faq.php" class="menu_list opa link">	
					<div><p class="kerning">よくあるご質問</p></div>
					<div>
						<p class="kerning en0">FAQ　</p>
						<p class="kerning en0">FAQ　</p>
						<p class="kerning en0"><span>FAQ　</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/company.php" class="menu_list opa link">	
					<div><p class="kerning">企業情報</p></div>
					<div>
						<p class="kerning en0">COMPANY</p>
						<p class="kerning en0">COMPANY</p>
						<p class="kerning en0"><span>COMPANY</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/contact/" class="menu_list opa link">	
					<div><p class="kerning">お問い合わせ</p></div>
					<div>
						<p class="kerning en0">CONTACT</p>
						<p class="kerning en0">CONTACT</p>
						<p class="kerning en0"><span>CONTACT</span></p>
					</div><div class="clear"></div>												
				</a>
			</div>
			<div class="menu_sns opa">
				<a href="https://www.facebook.com/%E5%90%88%E5%90%8C%E4%BC%9A%E7%A4%BE%E9%A1%94%E6%99%B4%E3%82%8C%E5%A1%A9%E7%AB%88-1938148653124259/" target="_blank"><img src="https://mosio.co.jp/img/sns2_w.svg" alt="FACEBOOK"></a>	
				<!--<a href="" target="_blank"><img src="https://mosio.co.jp/img/sns1_w.svg" alt="INSTAGRAM"></a>--><div class="clear"></div>				
			</div>
		</div>
	</div>	


	<!--/CONTENTS/-->
	<div id="top" class="contents">
		<!--/ABOUT/-->	
		<div id="about" class="contents_inner">



			<!--/MAIN/-->
			<div class="contents_main fix_h">
				<div class="contents_main_inner">
					<div class="contents_main_left title_w">
						<a href="/" class="contents_main_logo link"><img src="/img/logo0.svg" alt="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO"></a>
						<div class="contents_main_title"><img src="/img/title2.svg" alt="藻塩について"></div>					
					</div>
					<div class="contents_main_right">
						<div class="contents_main_img"><div></div></div>
					</div>
				</div>
			</div>



			<!--/DETAIL/-->
			<div class="contents_detail">
				<div class="contents_detail_inner">



					<div id="subtitle" class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner contents_w">
							<div class="contents_block_subtitle"><p class="kerning en0">ABOUT</p></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_left">
								<div class="contents_block_title"><img src="/img/title9.svg" alt="歴史と風土"><p class="kerning en0">HISTORY & CLIMATE</p></div>
							</div>
							<div class="contents_block_right">
								<div class="about_title"><p class="kerning ja0">塩竈と製塩文化</p></div>
								<div class="about_text">
									<p class="kerning">塩竈市は、宮城県中央部の小さな港町です。「塩竈」とは本来、製塩用の竈（かまど）を意味します。現在の塩竈市を含む湾岸地域一帯で古くから製塩が盛んだったことに由来する地名と考えられています。<br><br>またこの地は、日本各地に塩作りを伝えた塩土老翁神（しおつちおじのかみ）が最後に訪れ、定住した土地として知られています。市内にある御釜神社では今も、塩土老翁神の製塩法を引き継ぐ「藻塩焼神事（もしおやきしんじ）」が毎年厳かに行われ、作られた塩は鹽竈神社（しおがまじんじゃ）の例大祭で奉納されます。</p>
									<div></div>
									<p class="kerning">Shiogama is a small port city in the middle of the Miyagi prefecture. The Japanese characters for the name Shiogama use the characters for ‘salt’ and ‘pot,’ a pot being an essential tool in salt production. Including modern day Shiogama City, this entire coastal bay area was a prosperous salt-making region during the Jomon Period (around 11,000BCE to 1,000BCE), and it is thought that this was the origin of the name “Shiogama.”<br><br>It is also believed that Shiotsuchiojinokami, the God of the Tides, who visited all parts of Japan and taught salt-making, came to Shiogama last and settled down here. This is a deeply held belief, and even in modern times at the Okama Shrine within the city limits, moshioyaki, or the heirloom Shinto ritual of making salt from seaweed, is solemnly observed each year.</p>
								</div>		
							</div><div class="clear"></div>
						</div>
					</div>



					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_left"></div>
							<div class="contents_block_right">
								<div class="about_illust"><img src="/img/illust0.svg"></div>		
							</div><div class="clear"></div>
						</div>
					</div>
						


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_left"></div>
							<div class="contents_block_right">
								<div class="about_title"><p class="kerning ja0">塩竈・千賀ノ浦の風景</p></div>
								<div class="about_text">
									<p class="kerning">塩竈の海・塩釜湾は、絶景で知られる松島湾の南西部に位置しています。浅く穏やかな松島湾の海はたくさんの魚や海藻を育み、古来、湾域の住民に豊かな恵みをもたらしてきました。<br><br>「千賀ノ浦」の名で古の歌にも詠まれた塩釜湾の風景は、地域の暮らしを支える海として人々に親しまれています。</p>
									<div></div>
									<p class="kerning">Shiogama Bay is located in the southwestern part of Matsushima Bay, which is known for its scenery. Due to Matsushima Bay’s mild weather, the seawater is nutrient-packed and able to nurture many types of fish and seaweed.<br><br>The people here are intimately connected with the sea as an entity that supports regional life. The bay scenery visible from the city, referred to by its poetic name, Chiganoura, is praised in traditional songs called waka.</p>
								</div>		
							</div><div class="clear"></div>
						</div>
					</div>



					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_left"></div>
							<div class="contents_block_right">
								<div class="about_illust"><img src="/img/illust1.svg"></div>		
							</div><div class="clear"></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_left"></div>
							<div class="contents_block_right">
								<div class="about_title"><p class="kerning ja0">藻塩焼神事のおはなし</p></div>
								<div class="about_text">
									<p class="kerning">塩土老翁神の塩作りを今に伝える藻塩焼神事は、毎年7月、3日間にわたって行われます。<br><br>初日、塩竈市の隣町・七ヶ浜町の花渕浜の沖で、神馬藻（ほんだわら。海藻の一種）を刈り取ります。<br>2日目、松島湾の釜ケ淵で満潮時に潮水を汲み取り、御釜神社に運びます。<br>最終日、神馬藻で濾した潮水を鉄製の平釜に入れ、塩竈石の竈で炊き上げます。<br><br>こうしてできた藻塩は、御釜神社と鹽竈神社の神前に供えられます。</p>
									<div></div>
									<p class="kerning">The three day moshioyaki shinji, or the Shinto ritual of making salt out of seaweed, teaches about ancient salt-making. On the first day, seaweed grown in the open waters outside of the nearby Shichigahama Town’s Hanabushi Shrine is harvested. On the second day, at high tide water is drawn from Matsushima Bay’s Kamagafuchi area and carried to Okama Shrine. On the final day, seawater is boiled in an iron flat kettle that has been placed in a larger pot.<br><br>The larger pot is heated by a fire started with flint, and the flat kettle is filled with sea water strained through the seaweed. The process of straining seawater with seaweed is characteristic of Shiogama salt-production methods. This salt is then offered before the altars at Okama Shrine and Shiogama Shrine.</p>
								</div>		
							</div><div class="clear"></div>
						</div>
					</div>



					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img6"><img src="/img/transparent0.png"></div>
								</div>
							</div>							
						</div>
					</div>
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img7"><img src="/img/transparent0.png"></div>
								</div>
							</div>							
						</div>
					</div>



					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_left">
								<div class="contents_block_title"><img src="/img/title10.svg" alt="伝統の製法"><p class="kerning en0">TRADITIONAL PROCESS</p></div>
							</div>
							<div class="contents_block_right">
								<div class="about_title"><p class="kerning ja0">塩竈の藻塩の製法</p></div>
								<div class="about_text">
									<p class="kerning">弊社の塩作りは、塩土老翁神の製塩法を踏襲するものです。<br><br>塩竈沖の潮水を神馬藻で濾し、竈でじっくり炊いていきます。丁寧にアクを取りながら10時間以上炊き、火を止めて一晩静かに寝かせると、塩分濃度の高い鹹水（かんすい）となります。このとき、気温や濃度等の条件が揃うと、鹹水中に薄片状の結晶が生じます。結晶の生成は自然にゆだね、この工程には人の手を加えません。<br><br>こうしてできた結晶が「竈炊キ結晶（選別品）」です。また、結晶をすくった後の鹹水をさらに１日炊いたものが「竈炊キ藻塩（選別品）」となります。</p>
									<div></div>
									<p class="kerning">Our company’s salt production emulates those techniques taught by Shiotsuchiojinokami, the God of the Tides. Seawater from Shiogama is filtered through seaweed, then is carefully boiled in a flat kettle. Impurities are thoroughly removed over the eleven hours that the water is boiled, then after the fire is extinguished and the kettle left to cool for one night the crystalized salt is finished.<br><br>Salt prepared in this manner is called Kamadodaki Kessho, or “Kamado-boiled crystals.” A kamado is a type of traditional Japanese stove. The brine left over after the crystals have been scooped out is boiled for another day and becomes pure white Kamadodaki Moshio “Kamado-boiled seaweed salt.”</p>
								</div>		
							</div><div class="clear"></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img8"><img src="/img/transparent0.png"></div>
								</div>
							</div>							
						</div>
					</div>
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img9"><img src="/img/transparent0.png"></div>
								</div>
							</div>							
						</div>
					</div>	
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_left">
								<div class="contents_block_title"><img src="/img/title11.svg" alt="特徴と味わい"><p class="kerning en0">FEATURES & TASTE</p></div>
							</div>
							<div class="contents_block_right">
								<div class="about_title"><p class="kerning ja0">塩竈の藻塩の味わい</p></div>
								<div class="about_text">
									<p class="kerning">手間暇をかけて炊き上げた藻塩は雑味が少なく、まろやかで上品な味わいが特徴です。海鮮料理や天ぷら、サラダ、ステーキなど、どんな料理に合わせても食材の魅力を引き出してくれます。<br><br>サクサクした歯ざわりを楽しめる「竈炊キ結晶」と軽い口どけの「竈炊キ藻塩」。2種類の『塩竈の藻塩』の味の違いをぜひお楽しみ下さい。</p>
									<div></div>
									<p class="kerning">The taste of hand-prepared seaweed salt is gentle and refined. The salt brings out the unique tastes of ingredients and pairs well with many different types of foods like seafood, tempura, salads, and steaks. Through the lightly crunchy feeling of the “kamado-boiled crystals” that slowly melt in your mouth you can savor the deep flavor of the salt. The “kamado-boiled seaweed salt” is not bitter, but instead has a deeply appealing mild flavor.</p>
								</div>		
							</div><div class="clear"></div>
						</div>
					</div>



					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img0"><img src="/img/transparent0.png"></div>
								</div>
							</div>							
						</div>
					</div>
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img1"><img src="/img/transparent0.png"></div>
								</div>
							</div>							
						</div>
					</div>



				</div>
			</div>



		</div>
	</div>



	<!--/FOOTER/-->
	<div class="footer scroll_element scroll_off">	
		<div class="footer_inner">	
			<div class="footer_button">	
				<a href="https://mosio.co.jp/shop.php" class="link"><span></span><p class="kerning en0">SHOP</p><p class="kerning ja0">販売店一覧</p></a>
				<a href="https://mosio.co.jp/contact/" class="link"><span></span><p class="kerning en0">CONTACT</p><p class="kerning ja0">お問い合わせ</p></a><div class="clear"></div>
			</div>	
			<a href="https://mosio.co.jp/" class="footer_logo link"><img src="https://mosio.co.jp/img/logo0.svg" alt="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO"></a>		
			<div class="footer_text">	
				<p class="kerning">合同会社 顔晴れ塩竈</p>
				<p class="kerning">事務所<br>〒985‐0021 宮城県塩竈市尾島町27‐30キクニ（株）2F<br>TEL.022‐365‐5572　FAX.022‐361‐3370</p>
				<p class="kerning">工場<br>〒985‐0016 宮城県塩竈市港町二丁目15‐9<br>TEL.022‐367‐6539　FAX.022‐367‐6539</p><div class="clear"></div>
			</div>		
			<div class="footer_sns">	
				<a href="https://www.facebook.com/%E5%90%88%E5%90%8C%E4%BC%9A%E7%A4%BE%E9%A1%94%E6%99%B4%E3%82%8C%E5%A1%A9%E7%AB%88-1938148653124259/" target="_blank"><img src="https://mosio.co.jp/img/sns0_b.svg" alt="FACEBOOK"></a>	
				<!--<a href="" target="_blank"><img src="https://mosio.co.jp/img/sns1_b.svg" alt="INSTAGRAM"></a>--><div class="clear"></div>
			</div>	
			<a href="https://mosio.co.jp/notices.php" class="footer_notices link"><p class="kerning">特定商取引法に基づく表記</p></a>					
			<div class="footer_copyright"><p class="kerning">© 2017 GANBARE SHIOGAMA LLC</p></div>	
		</div>	
	</div>	
	
	

</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="https://mosio.co.jp/js/jquery-2.1.3.min.js"><\/script>')</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?language=en&key=AIzaSyAi_P2BfqNYcPbD-5mj6uYFJVidhSJjMXk"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.bxslider.min.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.pjax.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/common.js?201903"></script>



</body>
</html>