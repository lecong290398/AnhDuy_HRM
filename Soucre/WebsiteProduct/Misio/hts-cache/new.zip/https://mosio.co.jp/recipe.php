<!DOCTYPE html>
<html lang="ja">
<head>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-108057721-1', 'auto');
  ga('send', 'pageview');

</script><meta charset="utf-8">
<title>藻塩レシピ｜RECIPE｜塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO</title>



<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="format-detection" content="telephone=no">
<meta name="description" content="塩竈の藻塩は、宮城県塩竈市に塩土老翁神が伝えたとされる伝統的な製法に習い製塩されています。SHIOGAMA NO MOSHIO is made in traditional way in Shiogama City, Miyagi prefecture.">
<meta name="keywords" content="塩竈の藻塩,塩竈製塩,合同会社顔晴れ塩竈,SHIOGAMA NO MOSHIO,SHIOGAMA SEIEN,GANBARE SHIOGAMA LLC">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<meta property="og:site_name" content="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO">
<meta property="og:description" content="塩竈の藻塩は、宮城県塩竈市に塩土老翁神が伝えたとされる伝統的な製法に習い製塩されています。SHIOGAMA NO MOSHIO is made in traditional way in Shiogama City, Miyagi prefecture.">
<meta property="og:image" content="https://mosio.co.jp/img/fb_thumbnail.png">
<link rel="apple-touch-icon" href="https://mosio.co.jp/img/apple-touch-icon.png">
<link rel="icon" type="image/x-icon" href="https://mosio.co.jp/img/favicon.ico">
<link rel="canonical" href="https://mosio.co.jp">



<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Cinzel|Lato">
<link rel="stylesheet" type="text/css" href="https://mosio.co.jp/css/style.css?201909">
<link rel="stylesheet" type="text/css" href="https://mosio.co.jp/css/common.css?2021">



</head>
<body>



<!--/WRAP/-->
<div class="wrap">



	<!--/OPENING/-->
	<div class="opening">		
		<div class="opening_bar"><span></span></div>	
		<div class="opening_text"><p class="kerning en0">
			<span class="opa">S</span><span class="opa">H</span><span class="opa">I</span><span class="opa">O</span><span class="opa">G</span><span class="opa">A</span><span class="opa">M</span><span class="opa">A</span><span class="opa">&nbsp;</span><span class="opa">N</span><span class="opa">O</span><span class="opa">&nbsp;</span><span class="opa">M</span><span class="opa">O</span><span class="opa">S</span><span class="opa">H</span><span class="opa">I</span><span class="opa">O</span>
		</p></div>	
	</div>	
	


	<!--/LOADING/-->
	<div class="loading none">		
		<div class="loading_inner">
			<div class="loading_blue"></div>	
			<div class="loading_white"></div>	
		</div>	
	</div>	



	<!--/HEADER/-->
	<div class="header">	
		<a href="javascript:void(0);" class="header_button">
			<div class="header_button_bg opa"></div>	
			<div class="header_button_inner">
				<div><span></span><span></span><span></span></div>
				<div><span></span><span></span><span></span></div>
				<div><span></span><span></span><span></span></div>	
			</div>			
		</a>	
	</div>	



	<!--/MENU/-->
	<div class="menu none">	
		<div class="menu_inner opa">
			<div class="menu_bg"></div>		
			<div class="menu_block">	
				<a href="https://mosio.co.jp/" class="menu_list opa link">	
					<div><p class="kerning">ホーム</p></div>
					<div>
						<p class="kerning en0">HOME</p>
						<p class="kerning en0">HOME</p>
						<p class="kerning en0"><span>HOME</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/product.php" class="menu_list opa link">	
					<div><p class="kerning">塩竈の藻塩</p></div>
					<div>
						<p class="kerning en0">PRODUCT</p>
						<p class="kerning en0">PRODUCT</p>
						<p class="kerning en0"><span>PRODUCT</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/about.php" class="menu_list opa link">	
					<div><p class="kerning">藻塩について</p></div>
					<div>
						<p class="kerning en0">ABOUT</p>
						<p class="kerning en0">ABOUT</p>
						<p class="kerning en0"><span>ABOUT</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/recipe.php" class="menu_list opa link">	
					<div><p class="kerning">藻塩レシピ</p></div>
					<div>
						<p class="kerning en0">RECIPE</p>
						<p class="kerning en0">RECIPE</p>
						<p class="kerning en0"><span>RECIPE</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/column.php" class="menu_list opa link">	
					<div><p class="kerning">人々のはなし</p></div>
					<div>
						<p class="kerning en0">COLUMN</p>
						<p class="kerning en0">COLUMN</p>
						<p class="kerning en0"><span>COLUMN</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/shop.php" class="menu_list opa link">	
					<div><p class="kerning">販売店一覧</p></div>
					<div>
						<p class="kerning en0">SHOP</p>
						<p class="kerning en0">SHOP</p>
						<p class="kerning en0"><span>SHOP</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/faq.php" class="menu_list opa link">	
					<div><p class="kerning">よくあるご質問</p></div>
					<div>
						<p class="kerning en0">FAQ　</p>
						<p class="kerning en0">FAQ　</p>
						<p class="kerning en0"><span>FAQ　</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/company.php" class="menu_list opa link">	
					<div><p class="kerning">企業情報</p></div>
					<div>
						<p class="kerning en0">COMPANY</p>
						<p class="kerning en0">COMPANY</p>
						<p class="kerning en0"><span>COMPANY</span></p>
					</div><div class="clear"></div>												
				</a>
				<a href="https://mosio.co.jp/contact/" class="menu_list opa link">	
					<div><p class="kerning">お問い合わせ</p></div>
					<div>
						<p class="kerning en0">CONTACT</p>
						<p class="kerning en0">CONTACT</p>
						<p class="kerning en0"><span>CONTACT</span></p>
					</div><div class="clear"></div>												
				</a>
			</div>
			<div class="menu_sns opa">
				<a href="https://www.facebook.com/%E5%90%88%E5%90%8C%E4%BC%9A%E7%A4%BE%E9%A1%94%E6%99%B4%E3%82%8C%E5%A1%A9%E7%AB%88-1938148653124259/" target="_blank"><img src="https://mosio.co.jp/img/sns2_w.svg" alt="FACEBOOK"></a>	
				<!--<a href="" target="_blank"><img src="https://mosio.co.jp/img/sns1_w.svg" alt="INSTAGRAM"></a>--><div class="clear"></div>				
			</div>
		</div>
	</div>	


	<!--/CONTENTS/-->
	<div id="top" class="contents">
		<!--/RECIPE/-->	
		<div id="recipe" class="contents_inner">



			<!--/MAIN/-->
			<div class="contents_main fix_h">
				<div class="contents_main_inner">
					<div class="contents_main_left title_w">
						<a href="/" class="contents_main_logo link"><img src="/img/logo0.svg" alt="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO"></a>
						<div class="contents_main_title"><img src="/img/title3.svg" alt="藻塩レシピ"></div>					
					</div>
					<div class="contents_main_right">
						<div class="contents_main_img"><div></div></div>
					</div>
				</div>
			</div>



			<!--/DETAIL/-->
			<div class="contents_detail">
				<div class="contents_detail_inner">



					<div id="subtitle" class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner contents_w">
							<div class="contents_block_subtitle"><p class="kerning en0">RECIPE</p></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_block_text"><p class="kerning ja0">クセが少なくまろやかな『塩竈の藻塩』は、<br>さまざまな食材の味わいを<br class="sp_disp">最大限に引き出してくれます。<br>簡単な使用例をいくつかご提案します。</p></div>
						</div>
					</div>
					


					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img5"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>							
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">マグロ刺身と藻塩</p></div>
									<div class="recipe_text"><p class="kerning ja0">藻塩と柑橘の香りが絶妙に合う、<br class="sp_disp">海鮮に藻塩を合わせる定番です。<br>柑橘類はすだちがおすすめです。<br>柑橘類を絞り果汁を塩に染み込ませ、<br class="sp_disp">塩が溶け出したところを味わいます。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">マグロの刺身に結晶塩をのせます。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">その上から柑橘類を絞り、果汁を塩に染み込ませます。</p><div class="clear"></div></div>
										<div><p class="kerning">3.</p><p class="kerning">塩が溶け出したところを味わいます。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">マグロ（赤身〜中トロ）<br>柑橘類<br>竈炊キ結晶</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img4"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>	
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">カリカリ鶏肉と藻塩</p></div>
									<div class="recipe_text"><p class="kerning ja0">ソテーした香ばしさと鶏肉の食感を損なうことなく<br class="sp_disp">藻塩で味わう、飽きのこない一品です。<br>カリカリに焼いた鶏肉の肉汁と藻塩が合わさって<br class="sp_disp">旨味が引き出されます。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">ポリ袋に鶏肉と香草と塩を入れて軽く揉みます。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">フライパンで鶏肉の皮面からソテーします。</p><div class="clear"></div></div>
										<div><p class="kerning">3.</p><p class="kerning">皮面がカリカリに焼けていれば裏返して、弱火で焼きます。</p><div class="clear"></div></div>
										<div><p class="kerning">4.</p><p class="kerning">両面に火が通ったら、藻塩を振り味付けします。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">鶏肉<br>香草<br>竈炊キ藻塩</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img12"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>		
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">目玉焼きと藻塩</p></div>
									<div class="recipe_text"><p class="kerning ja0">朝食の定番の目玉焼きは<br class="sp_disp">卵そのままの味を楽しめる調理法です。<br>シンプルに卵を味わいたい時には<br class="sp_disp">藻塩がおすすめです。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">フライパンに油をひき、温めます。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">卵を割り入れ、弱火でじっくり焼きます。</p><div class="clear"></div></div>
										<div><p class="kerning">3.</p><p class="kerning">焼きあがったら藻塩を振ります。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">卵<br>竈炊キ藻塩</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img10"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>		
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">トマトと藻塩</p></div>
									<div class="recipe_text"><p class="kerning ja0">やさしい塩味が<br class="sp_disp">トマトの甘みと旨みを引き立てます。<br>結晶塩のザクザクとした食感を楽しみながら、<br class="sp_disp">素材の味をそのまま味わう<br class="sp_disp">シンプルな使い方です。<br>カットしたトマトに塩を振り味わいます。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">トマトをカットします。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">結晶塩を振ります。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">中玉トマト<br>竈炊キ結晶</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img11"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>		
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">じゃがいもと藻塩</p></div>
									<div class="recipe_text"><p class="kerning ja0">じゃがいもを蒸したホクホクの食感と<br class="sp_disp">自然な甘みと香りを塩で味わう一品です。<br>くせのない塩味でじゃがいも本来の味を楽しめます。<br>蒸したじゃがいもに塩を振るだけ。<br class="sp_disp">お好みで香草や胡椒を合わせます。	</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">じゃがいもに十字の切り込みを入れます。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">じゃがいもを蒸し器で20分蒸します。</p><div class="clear"></div></div>
										<div><p class="kerning">3.</p><p class="kerning">蒸したじゃがいもに藻塩を振ります。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">ジャガイモ<br>竈炊キ藻塩</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img15"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>		
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">アイスクリームと藻塩</p></div>
									<div class="recipe_text"><p class="kerning ja0">アイスクリームに藻塩を振ると<br class="sp_disp">より上品さが増すアクセントになります。<br>藻塩に含まれるミネラル分も加味されて、<br>甘みを際立たせながら後味はさっぱりと楽しめます。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">アイスクリームに結晶塩を振ります。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">アイスクリーム<br>竈炊キ結晶</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>			
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img17"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>			
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">コーヒーと藻塩</p></div>
									<div class="recipe_text"><p class="kerning ja0">コーヒー発祥の地で飲まれている塩コーヒー。<br>塩ひとつまみ入れると、コーヒーの酸味を和らげ、<br class="sp_disp">まろやかで奥行きのある味わいになります。<br>酸味のあるコーヒーにオススメです。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">コーヒーに藻塩をひとつまみ振ります。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">スプーンで一混ぜします。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">ホットコーヒー<br>竈炊キ藻塩</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>						
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img16"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>				
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">焼酎ハイボールと藻塩</p></div>
									<div class="recipe_text"><p class="kerning ja0">焼酎ハイボールに結晶塩を振り、<br class="sp_disp">混ぜずに結晶を静かに溶かしながら味わいます。<br>底に近づくほどに塩味を感じる爽やかな飲み口です。<br>塩味を効かせる時はグラス縁をスノースタイルに。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">グラスに氷を入れます。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">グラスに焼酎ハイボールを注ぎます。</p><div class="clear"></div></div>
										<div><p class="kerning">3.</p><p class="kerning">結晶塩を振ります。（かき混ぜない）</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">ハイボール<br>氷<br>レモン<br>竈炊キ結晶</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>					
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img14"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>	
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">ハーブソルト</p></div>
									<div class="recipe_text"><p class="kerning ja0">肉、魚介、野菜どんな料理にも相性が良く、<br>一振りするだけで<br class="sp_disp">味に深みを与えてくれるハーブソルトです。<br>ハーブの合わせ方で様々にアレンジが楽しめます。<br>生ハーブを使うと香りが良くて<br class="sp_disp">美味しいのでおすすめです。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">お好みの香草を電子レンジで乾燥するまで加熱します。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">乾燥したハーブを細かく刻みます。</p><div class="clear"></div></div>
										<div><p class="kerning">3.</p><p class="kerning">ハーブの2〜3倍の塩を加えて軽く混ぜます。</p><div class="clear"></div></div>
										<div><p class="kerning">4.</p><p class="kerning">保存瓶に入れて冷蔵庫で保存します。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">ハーブ<br>瓶<br>竈炊キ藻塩</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>				
					
					
					
					<div class="contents_block scroll_element scroll_off">
						<div class="contents_block_inner">
							<div class="contents_img">
								<div class="contents_img_inner">
									<div class="detail_img detail_img13"><img src="/img/transparent0.png"></div>
								</div>
								<a href="javascript:void(0);" class="recipe_button">
									<div class="recipe_button_inner">
										<div><span></span></div>
										<div><span></span></div>
									</div>
								</a>
							</div>		
							<div class="recipe_detail opa">
								<div class="recipe_detail_inner">
									<div class="recipe_title"><p class="kerning ja0">藻塩ドレッシング</p></div>
									<div class="recipe_text"><p class="kerning ja0">海水と海藻のみを原料につくった塩なので、<br>こだわりのオイルや酢とともに合わせて、<br class="sp_disp">ご家庭で無添加のドレッシングが簡単に作れます。<br>身体にいいものを美味しく食べるための<br class="sp_disp">ドレッシングです。</p></div>
									<div class="recipe_howto">
										<div><p class="kerning">作り方</p></div>
										<div><p class="kerning">1.</p><p class="kerning">オリーブオイルと酢（1：1）を混ぜ合わせます。</p><div class="clear"></div></div>
										<div><p class="kerning">2.</p><p class="kerning">お好みで香草や香辛料などを加えます。</p><div class="clear"></div></div>
										<div><p class="kerning">3.</p><p class="kerning">結晶塩を振り軽く合わせます。</p><div class="clear"></div></div>
									</div>
									<div class="recipe_material">
										<div><p class="kerning">材料</p></div>
										<div><p class="kerning">オリーブオイル<br>酢<br>香草<br>香辛料<br>竈炊キ結晶</p><div class="clear"></div></div>
									</div><div class="clear"></div>
								</div>
							</div>												
						</div>
					</div>					
										


				</div>
			</div>



		</div>
	</div>



	<!--/FOOTER/-->
	<div class="footer scroll_element scroll_off">	
		<div class="footer_inner">	
			<div class="footer_button">	
				<a href="https://mosio.co.jp/shop.php" class="link"><span></span><p class="kerning en0">SHOP</p><p class="kerning ja0">販売店一覧</p></a>
				<a href="https://mosio.co.jp/contact/" class="link"><span></span><p class="kerning en0">CONTACT</p><p class="kerning ja0">お問い合わせ</p></a><div class="clear"></div>
			</div>	
			<a href="https://mosio.co.jp/" class="footer_logo link"><img src="https://mosio.co.jp/img/logo0.svg" alt="塩竈の藻塩｜塩竈製塩｜SHIOGAMA NO MOSHIO"></a>		
			<div class="footer_text">	
				<p class="kerning">合同会社 顔晴れ塩竈</p>
				<p class="kerning">事務所<br>〒985‐0021 宮城県塩竈市尾島町27‐30キクニ（株）2F<br>TEL.022‐365‐5572　FAX.022‐361‐3370</p>
				<p class="kerning">工場<br>〒985‐0016 宮城県塩竈市港町二丁目15‐9<br>TEL.022‐367‐6539　FAX.022‐367‐6539</p><div class="clear"></div>
			</div>		
			<div class="footer_sns">	
				<a href="https://www.facebook.com/%E5%90%88%E5%90%8C%E4%BC%9A%E7%A4%BE%E9%A1%94%E6%99%B4%E3%82%8C%E5%A1%A9%E7%AB%88-1938148653124259/" target="_blank"><img src="https://mosio.co.jp/img/sns0_b.svg" alt="FACEBOOK"></a>	
				<!--<a href="" target="_blank"><img src="https://mosio.co.jp/img/sns1_b.svg" alt="INSTAGRAM"></a>--><div class="clear"></div>
			</div>	
			<a href="https://mosio.co.jp/notices.php" class="footer_notices link"><p class="kerning">特定商取引法に基づく表記</p></a>					
			<div class="footer_copyright"><p class="kerning">© 2017 GANBARE SHIOGAMA LLC</p></div>	
		</div>	
	</div>	
	
	

</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="https://mosio.co.jp/js/jquery-2.1.3.min.js"><\/script>')</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?language=en&key=AIzaSyAi_P2BfqNYcPbD-5mj6uYFJVidhSJjMXk"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.nicescroll.min.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.bxslider.min.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/jquery.pjax.js"></script>
<script type="text/javascript" src="https://mosio.co.jp/js/common.js?201903"></script>



</body>
</html>